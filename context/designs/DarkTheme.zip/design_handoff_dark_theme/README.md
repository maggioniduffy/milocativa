# Handoff: MILOCATIVA Landing — Dark Theme

## Overview
A dark/light theme toggle for the MILOCATIVA landing page: a moon/sun button in the navbar that switches the entire page's color scheme via CSS custom properties, persisted across visits.

## About the Design Files
The bundled file (`MILOCATIVA Landing.dc.html`) is a **design reference built in an HTML prototyping tool** — it shows intended look and behavior, not production code to copy directly. The task is to **recreate this design in the target codebase's existing environment** (React, Vue, plain CSS, etc.) using its established patterns — or, if no environment exists yet, choose the most appropriate framework and implement it there. Do not ship this HTML file as-is; some markup depends on the prototyping tool's runtime (`support.js`, `<x-import>` custom elements) and won't work outside it.

## Fidelity
**High-fidelity.** Exact colors, tokens and toggle behavior below should be reproduced pixel-for-pixel. Layout/copy of the rest of the landing page is out of scope for this handoff — only the theming system and its wiring into the existing UI matter.

## How the Theme System Works

1. All colors are CSS custom properties defined on `:root`, with a second set defined under `html[data-theme="dark"]` that overrides them.
2. Theme switching is done by toggling an attribute: `document.documentElement.setAttribute('data-theme', 'dark' | 'light')`. No class toggling, no JS-driven inline styles — every themed value reads `var(--token)`.
3. On load, the saved preference is read from `localStorage` (key `milocativa-theme`); if none exists, it falls back to the OS preference via `window.matchMedia('(prefers-color-scheme: dark)')`.
4. Every toggle click writes the new value back to `localStorage` immediately so it persists across reloads/sessions.
5. Images get a subtle filter adjustment in dark mode: `html[data-theme="dark"] img { filter: brightness(.94) contrast(1.02); }` — keeps photography from looking blown out on a dark ground.

## Design Tokens

### Light (default, `:root`)
- `--bg`: #F7F9FA
- `--surface`: #FFFFFF
- `--surface-alt`: #EEF2F3
- `--text`: #0B1F26
- `--text-muted`: #3E545C
- `--text-mute2`: #6F8790
- `--border`: #DCE3E5
- `--border-strong`: #C9D3D6
- `--accent`: #0C5678 / `--accent-hover`: #0A465F / `--accent-rgb`: 12,86,120
- `--teal-rgb`: 14,140,127
- `--amber-rgb`: 217,142,30 (plus `--amber`, `--amber-2` role tokens)
- `--green`: role token, used for "available now" status text

### Dark (`html[data-theme="dark"]`)
- `--bg`: #0A141B
- `--surface`: #101E29
- `--surface-alt`: #16262F
- `--text`: #EAF2F5
- `--text-muted`: #A9BCC4
- `--text-mute2`: #7F97A0
- `--border`: #223440
- `--border-strong`: #33505C
- `--accent`: #3E9BC7 / `--accent-hover`: #5FB2D8 / `--accent-rgb`: 62,155,199
- `--teal`: #2FC7AC / `--teal-rgb`: 47,199,172
- `--amber`: #E0A542 / `--amber-2`: #F0AE45 / `--amber-rgb`: 224,165,66
- `--green`: #3BC98C

Note: some tokens (`--teal`, `--amber`, `--amber-2`, `--green`) are only explicitly assigned in the dark block in this prototype; in production define both light and dark values explicitly for every token (don't leave any role token undefined in the light scheme).

Typography (unrelated to theme, but used throughout): headings/body in **Plus Jakarta Sans** (400/500/600/700/800), one italic accent word set in **Instrument Serif**. Both loaded from Google Fonts.

## Components / Behavior

### Theme toggle button (navbar, right side, before "Perfil" link)
- 38×38px circle button, `border-radius: 999px`, `border: 1.5px solid var(--border)`, `background: var(--surface-alt)`, `color: var(--text)`.
- Hover: `background: var(--border-strong)`.
- Focus-visible: `outline: 2px solid var(--accent); outline-offset: 2px`.
- Icon: moon (Lucide "moon" glyph) shown when theme is light (click to go dark); sun (Lucide "sun" glyph) shown when theme is dark (click to go light) — i.e. the icon shown is the theme you'll switch TO. Icons are 18×18, `stroke="currentColor"`, `stroke-width="2"`.
- `aria-label="Cambiar tema"`.

### Transitions
- `body`/themed elements don't have explicit color transitions in this prototype — the swap is instant. If desired, add a short `transition: background-color .2s ease, color .2s ease` on `body` and card surfaces for a smoother swap (optional enhancement, not required for fidelity).
- The sticky navbar background itself transitions on scroll (`background-color .2s ease, box-shadow .2s ease, border-color .2s ease`) — unrelated to theme but co-located in the same element.

## State Management
- Single piece of state: `theme: 'light' | 'dark'`, initialized in `componentDidMount`/on-load from `localStorage.getItem('milocativa-theme')`, falling back to `prefers-color-scheme`.
- Toggle handler: flips the value, sets `data-theme` attribute on `<html>`, writes to `localStorage`, updates state/re-renders icon.
- No server/database persistence — purely client-side (`localStorage`).

## Assets
No image assets specific to the theme. Icons are inline SVG (Lucide moon/sun paths), reproduced above.

## Screenshots
- `screenshots/01-theme.png` — hero section, light mode.
- `screenshots/02-theme.png` — hero section, dark mode (same scroll position, for direct comparison).

## Files
- `MILOCATIVA Landing.dc.html` — full landing page prototype containing the dark theme implementation. Look for:
  - The `<style>` block defining `:root` and `html[data-theme="dark"]` tokens (near the top of `<helmet>`).
  - The theme toggle `<button>` in the navbar markup.
  - The `Component` class: `toggleTheme()`, `isDark`/`isLight` render values, and the `componentDidMount` theme-initialization logic.
